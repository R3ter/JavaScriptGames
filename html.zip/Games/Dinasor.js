var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");






function render(){

}



setInterval(render,20);